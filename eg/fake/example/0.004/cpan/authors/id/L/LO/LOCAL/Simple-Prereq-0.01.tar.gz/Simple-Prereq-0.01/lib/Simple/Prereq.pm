package Simple::Prereq;
our $VERSION = '0.01';
1
