package Provides::Inner::Util;
our $VERSION = '0.867';
package Provides::Inner;
our $VERSION = '0.001';
1
